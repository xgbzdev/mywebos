var list = document.getElementById("list"), KEY = "checklist-items";
var items = JSON.parse(localStorage.getItem(KEY) || '[{"t":"Try Firefox OS","d":true},{"t":"Install an app from Marketplace","d":false}]');
function save() { localStorage.setItem(KEY, JSON.stringify(items)); }
function render() {
  list.innerHTML = "";
  items.forEach(function (it, i) {
    var li = document.createElement("li"); if (it.d) li.className = "done";
    li.innerHTML = '<label><input type="checkbox"' + (it.d ? " checked" : "") + '><span></span></label><button>×</button>';
    li.querySelector("span").textContent = it.t;
    li.querySelector("input").onchange = function () { it.d = this.checked; save(); render(); };
    li.querySelector("button").onclick = function () { items.splice(i, 1); save(); render(); };
    list.appendChild(li);
  });
  document.getElementById("foot").textContent =
    items.filter(function (x) { return !x.d; }).length + " left";
}
document.getElementById("f").onsubmit = function (e) {
  e.preventDefault(); var t = document.getElementById("t");
  if (t.value.trim()) { items.push({ t: t.value.trim(), d: false }); t.value = ""; save(); render(); }
};
// Firefox OS API: read our own manifest
if (navigator.mozApps) {
  navigator.mozApps.getSelf().onsuccess = function (e) {
    var app = e.target.result; if (app && app.manifest.version)
      document.getElementById("ver").textContent = "v" + app.manifest.version;
  };
}
render();
